//
//  FavouriteCocktailsCD+CoreDataProperties.swift
//  
//
//  Created by Nick Chiloane on 2021/08/26.
//
//

import Foundation
import CoreData


extension FavouriteCocktailsCD {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<FavouriteCocktailsCD> {
        return NSFetchRequest<FavouriteCocktailsCD>(entityName: "FavouriteCocktailsCD")
    }

    @NSManaged public var favCocktailsID: String?

}
