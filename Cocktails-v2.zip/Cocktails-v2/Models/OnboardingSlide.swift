//
//  OnboardingSlide.swift
//  Cocktails v2
//
//  Created by Nick Chiloane on 2021/08/04.
//

import UIKit
 
struct Onboardingslide {
    let title : String
    let description : String
    let image : UIImage
}
