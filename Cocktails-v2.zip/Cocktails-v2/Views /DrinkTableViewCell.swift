//
//  DrinkTableViewCell.swift
//  Cocktails v2
//
//  Created by Nick Chiloane on 2021/07/26.
//

import UIKit

class DrinkTableViewCell: UITableViewCell {
    
    @IBOutlet weak var cocktailName: UILabel!
    //@IBOutlet weak var cocktailName: UILabel!
    @IBOutlet weak var drinkImg: UIImageView!
  //  @IBOutlet weak var drinkView: UIView!
    @IBOutlet weak var cocktailImg: UIImageView!
    @IBOutlet weak var DrinkView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
