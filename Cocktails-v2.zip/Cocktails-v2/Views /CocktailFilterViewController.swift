//
//  CocktailFilterViewController.swift
//  Cocktails v2
//
//  Created by Nick Chiloane on 2021/08/18.
//

import UIKit

class CocktailFilterViewController: UIViewController {

    var filterName : String?
    var filterURL : String?
    
    @IBOutlet weak var categories: UIButton!
    @IBOutlet weak var ingridents: UIButton!
    @IBOutlet weak var glasses: UIButton!
    @IBOutlet weak var alcoholic: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func pressed(_ sender: Any)
    {
        performSegue(withIdentifier: "cocktailFilterSegue", sender: sender)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        super.prepare(for: segue, sender: sender)
        if segue.identifier == "cocktailFilterSegue"
        {

            let senderButton = sender as! UIButton

            switch senderButton
            {
                case categories:
                    
                    let controller = segue.destination as? FilterViewController
                    filterName = "Categories"
                    filterURL = "https://www.thecocktaildb.com/api/json/v1/1/list.php?c=list"
                    controller?.filterName = filterName
                    controller?.filterURL = filterURL
                    
                case ingridents:
                    
                    let controller = segue.destination as? FilterViewController
                    filterName = "Ingredients"
                    filterURL = "https://www.thecocktaildb.com/api/json/v1/1/list.php?i=list"
                    controller?.filterName = filterName
                    controller?.filterURL = filterURL
                    
                case glasses:
                    
                    let controller = segue.destination as? FilterViewController
                    filterName = "Glasses"
                    filterURL = "https://www.thecocktaildb.com/api/json/v1/1/list.php?g=list"
                    controller?.filterName = filterName
                    controller?.filterURL = filterURL
                    
                case alcoholic:
                   
                    let controller = segue.destination as? FilterViewController
                    filterName = "Alcoholic"
                    filterURL = "https://www.thecocktaildb.com/api/json/v1/1/list.php?a=list"
                    controller?.filterName = filterName
                    controller?.filterURL = filterURL
                    
                default:
                    //default code
                    print("default scenario")
            }

        }
    }


}
