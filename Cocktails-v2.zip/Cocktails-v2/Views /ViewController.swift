//
//  ViewController.swift
//  Cocktails v2
//
//  Created by Nick Chiloane on 2021/07/19.
//

import UIKit
import MBProgressHUD

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    //@IBOutlet weak var DrinkTableView: UITableView!
    @IBOutlet weak var DrinkTableView: UITableView!
    let searchController = UISearchController(searchResultsController: nil)
    
    
    
    var drinkData = [DrinkProperties]()
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        return drinkData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = DrinkTableView.dequeueReusableCell(withIdentifier: "DrinkCell") as! DrinkTableViewCell
        cell.cocktailName.text = drinkData[indexPath.row].strDrink
        //cell.charNickname.text = characterDeats[indexPath.row].nickname
        // cell.charDob.text = characterDeats[indexPath.row].dob.uppercased()
        cell.cocktailImg.downloaded(from: (drinkData[indexPath.row].strDrinkThumb!))
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "ShowDetail", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        
        if let destination = segue.destination as? CocktailDetailsViewController
        {
            
            
            destination.drink = drinkData[(DrinkTableView.indexPathForSelectedRow?.row)!]
            destination.cocktailID = drinkData[(DrinkTableView.indexPathForSelectedRow?.row)!].idDrink
            
            
        }
    }
    override func viewDidLoad() {
        MBProgressHUD.showAdded(to: self.view, animated: true)
         
         DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
         MBProgressHUD.hide(for: self.view, animated: true)
         }
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        downloadDrinkJSON {
            // self.downloadDrinkJSON
            //   {
            
            print("its running")
            self.DrinkTableView.reloadData()
            //  }
            self.DrinkTableView.delegate = self
            self.DrinkTableView.dataSource = self
        }
        
        
    }
    func downloadDrinkJSON(completed: @escaping () -> ())
    {
        
        let url = URL(string: "https://www.thecocktaildb.com/api/json/v1/1/filter.php?g=Cocktail_glass")!
        let urlSession = URLSession.shared
        let urlRequest = URLRequest(url: url)
        
        let _: Void = urlSession.dataTask(with: urlRequest)
        {
            data, urlResponse, error in
            
            if let error = error
            {
                
                print("Error: \(error.localizedDescription)")
                return
            }
            
            guard let unwrappedData = data else
            {
                print("No data recieved")
                return
            }
            
            
            let jsonDecoder = JSONDecoder()
            
            do {
                self.drinkData = try jsonDecoder.decode(Drink.self, from: unwrappedData).drinks
                DispatchQueue.main.async {
                    completed()
                }
            } catch {
                print(error)
            }
        }.resume()
    }
}
extension UIImageView

{
    
    func downloaded(from url: URL, contentMode mode: ContentMode = .scaleAspectFit)
    
    {
        
        contentMode = mode
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            
            guard
                
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                
                let data = data, error == nil,
                
                let image = UIImage(data: data)
            
            else { return }
            
            DispatchQueue.main.async() { [weak self] in
                
                self?.image = image
                
            }
            
        }.resume()
        
    }
    
    func downloaded(from link: String, contentMode mode: ContentMode = .scaleAspectFit) {
        
        guard let url = URL(string: link) else { return }
        
        downloaded(from: url, contentMode: mode)
        
    }
}

