//
//  FavouritesViewController.swift
//  Cocktails v2
//
//  Created by Nick Chiloane on 2021/08/26.
//

import UIKit
import CoreData
class FavouritesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var FavouriteTableView: UITableView!
    // FavouriteCocktails
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    private var cdCocktailIDs = [FavouriteCocktailsCD]()
    var drinkData = [DrinkProperties]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        // Do any additional setup after loading the view.
    
}
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        drinkData.removeAll()
        self.FavouriteTableView.reloadData()
        getCDCocktails()
        
        downloadCocktailDetaillsJSON {
            print("Attempting to download cocktails")
            self.FavouriteTableView.reloadData()
            print("Done downloading cocktails")
        }
        FavouriteTableView.dataSource =  self
        FavouriteTableView.delegate = self
       
    }
   

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        return drinkData.count
    }
   
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
       
        let cell = FavouriteTableView.dequeueReusableCell(withIdentifier: "FavouriteDrinkCell", for: indexPath) as! FavouriteDrinkCustomCell
        cell.favouriteName.text = drinkData[indexPath.row].strDrink
       
        cell.favouriteImg.downloaded(from: (drinkData[indexPath.row].strDrinkThumb!))
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "FavouriteDetailsSegue", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        
        if let destination = segue.destination as? CocktailDetailsViewController
        {
            
            
            destination.drink = drinkData[(FavouriteTableView.indexPathForSelectedRow?.row)!]
            destination.cocktailID = drinkData[(FavouriteTableView.indexPathForSelectedRow?.row)!].idDrink
            
            
        }
    }
    // Core Data
    func getCDCocktails()
    {
        do
        {
            cdCocktailIDs = try context.fetch(FavouriteCocktailsCD.fetchRequest())
            
        }
        catch
        {
            print("Error Getting items: \(error.localizedDescription)")
        }
    }
    
    func downloadCocktailDetaillsJSON(completed: @escaping () -> ())
    {
        for i in 0 ..< cdCocktailIDs.count
        {
            let item = cdCocktailIDs[i].favCocktailsID as String?
            
            let queryURL = "https://www.thecocktaildb.com/api/json/v1/1/lookup.php?i=\(item!)"
            let url = URL(string: queryURL)!
            let urlSession = URLSession.shared
            let urlRequest = URLRequest(url: url)
            let task = urlSession.dataTask(with: urlRequest)
            {
                data, urlResponse, error in
                
                if let error = error
                {
                    
                    print("Error: \(error.localizedDescription)")
                    return
                }
                
                guard let unwrappedData = data else
                {
                    print("No data")
                    return
                }
                
                
                let jsonDecoder = JSONDecoder()

            do
            {
                let list = try jsonDecoder.decode(Drink.self, from: unwrappedData).drinks
                self.drinkData.append(contentsOf: list)
                DispatchQueue.main.async
                {
                    completed()
                }
                   
                } catch {
                    print(error)
                }
            }.resume()
        }
    
    }
}
