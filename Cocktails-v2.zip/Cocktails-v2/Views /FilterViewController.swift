//
//  FilterViewController.swift
//  Cocktails v2
//
//  Created by Nick Chiloane on 2021/08/23.
//

import UIKit

class FilterViewController: UIViewController, UITableViewDelegate, UITableViewDataSource  {
   
    var filterName : String?
    var filterURL : String?
    var chosenIngredient: String?
    var chosenAlcoholic: String?
    var chosenGlass: String?
    var chosenCategory: String?
    var drinkData = [DrinkProperties]()
    @IBOutlet weak var FilterTableView: UITableView!
  
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        downloadCategoriesDetaillsJSON {
            self.FilterTableView.reloadData()
           // print("this is the name \(self.filterName!) and this is the link: \(self.filterURL!)")
            // print(self.drinkData)
        }
        FilterTableView.delegate = self
        FilterTableView.dataSource = self
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return drinkData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = FilterTableView.dequeueReusableCell(withIdentifier: "FilterDrinkCell") as! FilterCustomCell
        
        
       
        switch filterName
        {
            case "Categories":
                chosenCategory = drinkData[indexPath.row].strCategory!
                cell.filterName?.text = drinkData[indexPath.row].strCategory!
                
                
            case "Glasses":
                chosenGlass = drinkData[indexPath.row].strGlass!
                cell.filterName?.text = drinkData[indexPath.row].strGlass!
           
                
            case "Ingredients":
                chosenIngredient = drinkData[indexPath.row].strIngredient1!
                cell.filterName?.text = drinkData[indexPath.row].strIngredient1!
                
                
            case "Alcoholic":
                chosenAlcoholic = drinkData[indexPath.row].strAlcoholic!
                cell.filterName?.text = drinkData[indexPath.row].strAlcoholic!
                
            default:
                print("No filter was chosen")
            
        }
     
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "CocktailsSegue", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        
        if let destination = segue.destination as? FilteredCocktailsViewController
        {
            destination.filterName = filterName
            
            if let chosenAlcoholic = chosenAlcoholic
            {
                destination.chosenAlcoholic = chosenAlcoholic
            }
            if let chosenIngredient = chosenIngredient
            {
                destination.chosenIngredient = chosenIngredient
            }
            
            if let chosenGlass = chosenGlass
            {
                destination.chosenGlass = chosenGlass
            }
            
            if let chosenCategory = chosenCategory
            {
                destination.chosenCategory = chosenCategory
            }
        }
    }
    
    func downloadCategoriesDetaillsJSON(completed: @escaping () -> ())
    {
    
    //print("The Query URL is: \(queryURL)")
    let url = URL(string: (filterURL)!)!
        let urlSession = URLSession.shared
        let urlRequest = URLRequest(url: url)

        let task = urlSession.dataTask(with: urlRequest)
        {
            data, urlResponse, error in
            
            if let error = error
            {
                
                print("Error: \(error.localizedDescription)")
                return
            }
            
            guard let unwrappedData = data else
            {
                print("No data")
                return
            }
            
            
            let jsonDecoder = JSONDecoder()

        do
        {
            self.drinkData = try jsonDecoder.decode(Drink.self, from: unwrappedData).drinks
                DispatchQueue.main.async
                {
                    completed()
                }
            } catch {
                print(error)
            }
            
        }.resume()
    
    }
    
}
