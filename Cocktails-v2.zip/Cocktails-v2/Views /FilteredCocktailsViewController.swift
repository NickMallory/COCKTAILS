//
//  FilteredCocktailsViewController.swift
//  Cocktails v2
//
//  Created by Nick Chiloane on 2021/08/23.
//

import UIKit

class FilteredCocktailsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var FilteredTableView: UITableView!
    var drinkData = [DrinkProperties]()
    var chosenIngredient: String?
    var chosenAlcoholic: String?
    var chosenGlass: String?
    var chosenCategory: String?
    var filterName : String?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        downloadCocktailsJSON {
            // self.downloadDrinkJSON
            //   {
            
            print("its running")
            self.FilteredTableView.reloadData()
            //  }
            self.FilteredTableView.delegate = self
            self.FilteredTableView.dataSource = self
        }
        
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        return drinkData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = FilteredTableView.dequeueReusableCell(withIdentifier: "CocktailCustomCell") as! CocktailCustomCell
        cell.cocktailName.text = drinkData[indexPath.row].strDrink
        
        cell.cocktailImg.downloaded(from: (drinkData[indexPath.row].strDrinkThumb!))
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        
        if let destination = segue.destination as? CocktailDetailsViewController
        {
            
            
            destination.drink = drinkData[(FilteredTableView.indexPathForSelectedRow?.row)!]
            destination.cocktailID = drinkData[(FilteredTableView.indexPathForSelectedRow?.row)!].idDrink
            
            
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "FilteredCocktails", sender: self)
    }
    
    func downloadCocktailsJSON(completed: @escaping () -> ())
     {
        var url:URL?
        
        switch filterName!
        {
            case "Categories":
                let yourString = "https://www.thecocktaildb.com/api/json/v1/1/filter.php?c=\((chosenCategory)!)"
                let urlNew:String = yourString.replacingOccurrences(of: " ", with: "_").trimmingCharacters(in: .whitespacesAndNewlines)
                url = URL(string: urlNew)!
                
            case "Glasses":
                let yourString = "https://www.thecocktaildb.com/api/json/v1/1/filter.php?g=\((chosenGlass)!)"
                let urlNew:String = yourString.replacingOccurrences(of: " ", with: "_").trimmingCharacters(in: .whitespacesAndNewlines)
                url = URL(string: urlNew)!
                
            case "Ingredients":
                let yourString = "https://www.thecocktaildb.com/api/json/v1/1/filter.php?i=\((chosenIngredient)!)"
                let urlNew:String = yourString.replacingOccurrences(of: " ", with: "+").trimmingCharacters(in: .whitespacesAndNewlines)
                url = URL(string: urlNew)!
                
            case "Alcoholic":
                let yourString = "https://www.thecocktaildb.com/api/json/v1/1/filter.php?a=\((chosenAlcoholic)!)"
                let urlNew:String = yourString.replacingOccurrences(of: " ", with: "_").trimmingCharacters(in: .whitespacesAndNewlines)
                url = URL(string: urlNew)!
                
            default:
                    print("No filter was chosen")
            
        }

         let urlSession = URLSession.shared
         let urlRequest = URLRequest(url: url!)

         let task = urlSession.dataTask(with: urlRequest)
         {
             data, urlResponse, error in
             
             if let error = error
             {
                 
                 print("Error: \(error.localizedDescription)")
                 return
             }
             
             guard let unwrappedData = data else
             {
                 print("No data")
                 return
             }
             
             
             let jsonDecoder = JSONDecoder()
  
            do
            {
                self.drinkData = try jsonDecoder.decode(Drink.self, from: unwrappedData).drinks
                    DispatchQueue.main.async
                    {
                        completed()
                    }
            }
            catch
            {
                print(error)
            }
         }.resume()
     }
}
