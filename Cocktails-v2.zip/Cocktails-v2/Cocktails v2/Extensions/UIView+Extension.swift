//
//  UIView+Extension.swift
//  Cocktails v2
//
//  Created by Nick Chiloane on 2021/08/04.
//

import UIKit
 
extension UIView {
   @IBInspectable var cornerRadius: CGFloat {
        get { return cornerRadius}
        set {
            self.layer.cornerRadius = newValue
    }
}
}
