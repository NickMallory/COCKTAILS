//
//  IngridientsCustomCell.swift
//  Cocktails v2
//
//  Created by Nick Chiloane on 2021/08/08.
//

import UIKit

class IngridientsCustomCell: UITableViewCell {
    
    @IBOutlet weak var measurements: UILabel!
    @IBOutlet weak var ingridents: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

