//
//  FavouriteDrinkCustomCell.swift
//  Cocktails v2
//
//  Created by Nick Chiloane on 2021/08/26.
//


import UIKit

class FavouriteDrinkCustomCell: UITableViewCell {
    
    
    @IBOutlet weak var favouriteName: UILabel!
    @IBOutlet weak var favouriteImg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

