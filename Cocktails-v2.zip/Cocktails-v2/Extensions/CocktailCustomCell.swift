//
//  CocktailCustomCell.swift
//  Cocktails v2
//
//  Created by Nick Chiloane on 2021/08/23.
//

import Foundation
import UIKit

class CocktailCustomCell: UITableViewCell {
    
    @IBOutlet weak var cocktailName: UILabel!
    @IBOutlet weak var cocktailImg: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
