//
//  FavouriteCocktailsCD+CoreDataClass.swift
//  
//
//  Created by Nick Chiloane on 2021/08/26.
//
//

import Foundation
import CoreData

@objc(FavouriteCocktailsCD)
public class FavouriteCocktailsCD: NSManagedObject {

}
