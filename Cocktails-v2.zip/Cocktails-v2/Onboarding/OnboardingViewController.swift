//
//  OnboardingViewController.swift
//  Cocktails v2
//
//  Created by Nick Chiloane on 2021/08/04.
// This is a test commit to Github

import UIKit

class OnboardingViewController: UIViewController {
    
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var slides: [Onboardingslide] = []
    
    
    var currentPage = 0 {
        didSet {
            pageControl.currentPage = currentPage
            if currentPage == slides.count - 1 {
                nextButton.setTitle("Get Started", for: .normal)
            } else {
                nextButton.setTitle("Next", for: .normal)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        slides = [
            Onboardingslide(title: "Fantastic Cocktails", description: "Expereriance the best drinks in the country! ", image: #imageLiteral(resourceName: "images")),
            //Onboardingslide(title: "ingredients", description: "Get to know what is inside your drink! ", image: #imageLiteral(resourceName: "20191115-virgin-pina-colada-delish-ehg-4387-1585599229")),
            Onboardingslide(title: "Sharing", description: "Have a drink with your people ", image: #imageLiteral(resourceName: "images-5"))
            //image: #imageLiteral(resourceName: "cocktails")
        ]
        pageControl.numberOfPages = slides.count
        print("This is the page: \(slides.count)")
        collectionView.delegate = self
        collectionView.dataSource = self
        
    }
    
    @IBAction func nextButton(_ sender: UIButton) {
        
        if currentPage == slides.count - 1 {
            let controller = storyboard?.instantiateViewController(identifier: "HomeTBC") as! UITabBarController
            controller.modalPresentationStyle = .fullScreen
            controller.modalTransitionStyle = .flipHorizontal
            present(controller, animated: true, completion: nil)
        }else {
            
            currentPage += 1

            let indexPath = IndexPath(item: currentPage, section: 0)
            collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        }
    }
    
}

extension OnboardingViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return slides.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: OnboardingCollectionViewCell.identifier, for: indexPath) as! OnboardingCollectionViewCell
        cell.setup(slides[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.height, height: collectionView.frame.height)
        
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let width = scrollView.frame.width
        currentPage = Int(scrollView.contentOffset.x / width)
        // pageControl.currentPage = currentPage
    }
}






