//
//  OnboardingCollectionViewCell.swift
//  Cocktails v2
//
//  Created by Nick Chiloane on 2021/08/05.
//

import UIKit

class OnboardingCollectionViewCell: UICollectionViewCell {
    
    static let identifier = String(describing: OnboardingCollectionViewCell.self)
    @IBOutlet weak var slideimageView: UIImageView!
    
    @IBOutlet weak var slidetitleLabel: UILabel!
    @IBOutlet weak var slidedescriptionLbl: UILabel!
    

    
    func setup(_ slide: Onboardingslide) {
        slideimageView.image = slide.image
        slidetitleLabel.text = slide.title
        slidedescriptionLbl.text = slide.description
    }
}
